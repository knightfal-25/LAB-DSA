import java.util.ArrayList;
import java.util.Collections;

public class ArrayListOperations {

    // Add element
    public static void addElement(ArrayList<Integer> list, int value) {
        list.add(value);
    }

    // Remove element by index
    public static void removeElement(ArrayList<Integer> list, int index) {
        if (index >= 0 && index < list.size()) list.remove(index);
    }

    // Search element
    public static int searchElement(ArrayList<Integer> list, int target) {
        return list.indexOf(target);
    }

    // Sort list
    public static void sortList(ArrayList<Integer> list) {
        Collections.sort(list);
    }

    // Traverse
    public static void traverse(ArrayList<Integer> list) {
        System.out.println(list);
    }
}
