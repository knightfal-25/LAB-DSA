import java.util.*;

public class Comparison {

    // ======================= Array Operations ========================
    static class ArrayOperations {
        public static void traverse(int[] array) {
            System.out.println(Arrays.toString(array));
        }

        public static int linearSearch(int[] array, int target) {
            for (int i = 0; i < array.length; i++) {
                if (array[i] == target) return i;
            }
            return -1;
        }

        public static int binarySearch(int[] array, int target) {
            int[] sorted = Arrays.copyOf(array, array.length);
            Arrays.sort(sorted);
            return Arrays.binarySearch(sorted, target);
        }

        public static int[] insert(int[] array, int index, int value) {
            int[] newArray = new int[array.length + 1];
            System.arraycopy(array, 0, newArray, 0, index);
            newArray[index] = value;
            System.arraycopy(array, index, newArray, index + 1, array.length - index);
            return newArray;
        }

        public static int[] delete(int[] array, int index) {
            int[] newArray = new int[array.length - 1];
            System.arraycopy(array, 0, newArray, 0, index);
            System.arraycopy(array, index + 1, newArray, index, array.length - index - 1);
            return newArray;
        }
    }

    // ======================= ArrayList Operations ========================
    static class ArrayListOperations {
        public static void addElement(ArrayList<Integer> list, int value) {
            list.add(value);
        }

        public static void removeElement(ArrayList<Integer> list, int index) {
            if (index >= 0 && index < list.size()) list.remove(index);
        }

        public static int searchElement(ArrayList<Integer> list, int target) {
            return list.indexOf(target);
        }

        public static void sortList(ArrayList<Integer> list) {
            Collections.sort(list);
        }

        public static void traverse(ArrayList<Integer> list) {
            System.out.println(list);
        }
    }

    // ======================= Main Method ========================
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50};
        ArrayList<Integer> arrayList = new ArrayList<>();
        for (int val : array) arrayList.add(val);

        System.out.println("+----------------------+-----------------------------+");
        System.out.printf("| %-20s | %-25s |\n", "Operasi", "Hasil");
        System.out.println("+----------------------+-----------------------------+");

        // Traversal
        System.out.printf("| %-20s | %-25s |\n", "Array Traversal", Arrays.toString(array));
        System.out.printf("| %-20s | %-25s |\n", "ArrayList Traversal", arrayList.toString());

        // Pencarian
        int target = 30;
        int indexArray = ArrayOperations.linearSearch(array, target);
        int indexList = ArrayListOperations.searchElement(arrayList, target);
        System.out.printf("| %-20s | %-25s |\n", "Cari 30 (Array)", "Index: " + indexArray);
        System.out.printf("| %-20s | %-25s |\n", "Cari 30 (ArrayList)", "Index: " + indexList);

        // Penyisipan
        array = ArrayOperations.insert(array, 2, 25);
        arrayList.add(2, 25);
        System.out.printf("| %-20s | %-25s |\n", "Insert 25 (Array)", Arrays.toString(array));
        System.out.printf("| %-20s | %-25s |\n", "Insert 25 (ArrayList)", arrayList.toString());

        // ================= Perbandingan waktu eksekusi =================
        int size = 1000;
        int[] bigArray = new int[size];
        ArrayList<Integer> bigList = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            bigArray[i] = i;
            bigList.add(i);
        }

        System.out.println("+----------------------+----------------+----------------+");
        System.out.printf("| %-20s | %-14s | %-14s |\n", "Operasi", "Array (ms)", "ArrayList (ms)");
        System.out.println("+----------------------+----------------+----------------+");

        // Linear Search
        long startTime = System.nanoTime();
        ArrayOperations.linearSearch(bigArray, size - 1);
        long endTime = System.nanoTime();
        double arrayLinearTime = (endTime - startTime) / 1_000_000.0;

        startTime = System.nanoTime();
        ArrayListOperations.searchElement(bigList, size - 1);
        endTime = System.nanoTime();
        double listLinearTime = (endTime - startTime) / 1_000_000.0;

        System.out.printf("| %-20s | %-14.5f | %-14.5f |\n", "Linear Search", arrayLinearTime, listLinearTime);

        // Binary Search
        startTime = System.nanoTime();
        ArrayOperations.binarySearch(bigArray, size - 1);
        endTime = System.nanoTime();
        double arrayBinaryTime = (endTime - startTime) / 1_000_000.0;

        startTime = System.nanoTime();
        Collections.sort(bigList);
        Collections.binarySearch(bigList, size - 1);
        endTime = System.nanoTime();
        double listBinaryTime = (endTime - startTime) / 1_000_000.0;

        System.out.printf("| %-20s | %-14.5f | %-14.5f |\n", "Binary Search", arrayBinaryTime, listBinaryTime);

        // Insert
        startTime = System.nanoTime();
        ArrayOperations.insert(bigArray, 500, 9999);
        endTime = System.nanoTime();
        double arrayInsertTime = (endTime - startTime) / 1_000_000.0;

        startTime = System.nanoTime();
        bigList.add(500, 9999);
        endTime = System.nanoTime();
        double listInsertTime = (endTime - startTime) / 1_000_000.0;

        System.out.printf("| %-20s | %-14.5f | %-14.5f |\n", "Insert", arrayInsertTime, listInsertTime);

        // Delete
        startTime = System.nanoTime();
        ArrayOperations.delete(bigArray, 500);
        endTime = System.nanoTime();
        double arrayDeleteTime = (endTime - startTime) / 1_000_000.0;

        startTime = System.nanoTime();
        bigList.remove(500);
        endTime = System.nanoTime();
        double listDeleteTime = (endTime - startTime) / 1_000_000.0;

        System.out.printf("| %-20s | %-14.5f | %-14.5f |\n", "Delete", arrayDeleteTime, listDeleteTime);
        System.out.println("+----------------------+----------------+----------------+");
    }
}
